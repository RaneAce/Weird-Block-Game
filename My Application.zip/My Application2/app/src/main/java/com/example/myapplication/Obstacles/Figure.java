package com.example.myapplication.Obstacles;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

public abstract class Figure {
    public int x;
    public int y;
    public Bitmap bitmap;

    public Figure(int x, int y, Bitmap bitmap){
        this.x = x;
        this.y = y;
        this.bitmap = bitmap;
    }

    public Boolean collision_1st_check (Block Block, Figure other){
        return (Block.getX() + Block.getBitmap().getWidth() >= other.getX() &&
                Block.getX() <= other.getX() + other.getBitmap().getWidth() &&
                Block.getY() + Block.getBitmap().getHeight() >= other.getY() &&
                Block.getY() <= other.getY() + other.getBitmap().getHeight());
    }

    public void Draw (Canvas canvas){
        canvas.drawBitmap(bitmap, x, y,null);
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }
}
