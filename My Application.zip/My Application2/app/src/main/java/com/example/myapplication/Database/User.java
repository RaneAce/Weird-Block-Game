package com.example.myapplication.Database;

public class User {
    private int uid;

    public User(int uid) {
        this.uid = uid;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }
}
