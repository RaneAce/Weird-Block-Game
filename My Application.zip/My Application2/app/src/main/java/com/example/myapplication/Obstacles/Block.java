package com.example.myapplication.Obstacles;

import android.graphics.Bitmap;

public class Block extends Figure {
    public Block(int x, int y, Bitmap bitmap){
        super(x, y, bitmap);
    }

}
