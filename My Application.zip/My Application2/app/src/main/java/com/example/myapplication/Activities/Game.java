package com.example.myapplication.Activities;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import com.example.myapplication.Obstacles.Block;
import com.example.myapplication.R;

    public class Game extends SurfaceView implements Runnable {
        private int width;
        private int height;
        private Canvas canvas;
        private Thread thread;
        private boolean isRunning = true;
        private SurfaceHolder holder;
        private Block block;
        private Paint bgPaint;
        private Bitmap imgBlock;

        int interval = -50;

        public Game(Context context, int width, int height){
            super(context);
            this.width = width;
            this.height = height;
            holder = getHolder(); //getting surface

            //image creating with drawables
            imgBlock = BitmapFactory.decodeResource(getResources(),R.drawable.elioramarli);
            imgBlock = Bitmap.createScaledBitmap(imgBlock,imgBlock.getWidth()/2,imgBlock.getHeight()/2,false);
            //creating objects
            block = new Block(width/2,height/2,imgBlock);
            //painting background
            bgPaint = new Paint();
            bgPaint.setColor(Color.WHITE);

            //running thread
            thread = new Thread(this);
            thread.start();
        }

        public void drawCanvas() {
            if(holder.getSurface().isValid()){
                canvas = holder.lockCanvas(); // canvas lock + create
                canvas.drawPaint(bgPaint); // paint bg
                block.Draw(canvas); //draw block
                holder.unlockCanvasAndPost(canvas); // unlock canvas after paint
            }
        }


        @Override
        public void run() {
            while(isRunning){
                drawCanvas();
            }
        }


    }



