package com.example.myapplication.Obstacles;

import android.graphics.Bitmap;

public class circle extends Figure {

    public circle(int x, int y, Bitmap bitmap){
        super(x, y, bitmap);
    }

}
