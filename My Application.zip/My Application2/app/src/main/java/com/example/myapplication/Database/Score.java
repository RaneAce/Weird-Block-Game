package com.example.myapplication.Database;

public class Score {
    private int date;
    private int uid;
    private int score;

    public Score(int date, int uid, int score){
        this.date = date;
        this.uid = uid;
        this.score = score;
    }

    public int getDate() {
        return date;
    }

    public int getScore() {
        return score;
    }

    public int getUid() {
        return uid;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }
}
